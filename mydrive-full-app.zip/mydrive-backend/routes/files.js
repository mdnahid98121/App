
const express = require('express');
const multer = require('multer');
const File = require('../models/File');
const router = express.Router();

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/'),
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});
const upload = multer({ storage });

router.post('/upload', upload.single('file'), async (req, res) => {
  const { userId } = req.body;
  const file = new File({
    userId,
    filename: req.file.filename,
    path: req.file.path,
    type: req.file.mimetype
  });
  await file.save();
  res.json({ message: 'File uploaded', file });
});

router.get('/:userId', async (req, res) => {
  const files = await File.find({ userId: req.params.userId });
  res.json(files);
});

module.exports = router;


const mongoose = require('mongoose');

const fileSchema = new mongoose.Schema({
  userId: String,
  filename: String,
  path: String,
  type: String,
  uploadedAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('File', fileSchema);


let userId = null;

function signup() {
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;

  fetch('http://localhost:5000/api/auth/signup', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password })
  })
  .then(res => res.json())
  .then(data => alert(data.message));
}

function login() {
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;

  fetch('http://localhost:5000/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password })
  })
  .then(res => res.json())
  .then(data => {
    if (data.userId) {
      userId = data.userId;
      document.getElementById('auth-section').style.display = 'none';
      document.getElementById('upload-section').style.display = 'block';
      document.getElementById('userDisplay').innerText = username;
      fetchFiles();
    } else {
      alert(data.message);
    }
  });
}

function uploadFile() {
  const fileInput = document.getElementById('fileInput');
  const file = fileInput.files[0];
  const formData = new FormData();
  formData.append('file', file);
  formData.append('userId', userId);

  fetch('http://localhost:5000/api/files/upload', {
    method: 'POST',
    body: formData
  })
  .then(res => res.json())
  .then(() => {
    fileInput.value = '';
    fetchFiles();
  });
}

function fetchFiles() {
  fetch('http://localhost:5000/api/files/' + userId)
    .then(res => res.json())
    .then(files => {
      const list = document.getElementById('fileList');
      list.innerHTML = '';
      files.forEach(file => {
        let item;
        if (file.type.startsWith('image/')) {
          item = document.createElement('img');
          item.src = 'http://localhost:5000/' + file.path;
          item.width = 200;
        } else {
          item = document.createElement('p');
          item.innerText = file.filename;
        }
        list.appendChild(item);
      });
    });
}
